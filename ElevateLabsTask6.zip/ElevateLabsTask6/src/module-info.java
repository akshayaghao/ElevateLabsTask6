/**
 * 
 */
/**
 * 
 */
module ElevateLabsTask6 {
	requires java.desktop;
}